# educative-course-jmeter
# DO NOT DELETE
This repo will store for work files for the course "Performance Testing with JMeter" on Educative.io
